import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles, Languages, GraduationCap } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { cn } from '../lib/utils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface Message {
  role: 'user' | 'model';
  text: string;
}

export default function AIChatScreen() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: '안녕하세요! (Hello!) I am your Korean AI Tutor. How can I help you today? We can practice conversation, explain grammar, or roleplay!' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'teacher' | 'friend' | 'kpop'>('teacher');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const systemInstruction = `
        You are a Korean language tutor. 
        Current Mode: ${mode}.
        - If 'teacher': Be formal, explain grammar, and correct mistakes.
        - If 'friend': Be casual (Banmal), use modern slang, and talk about daily life.
        - If 'kpop': Roleplay as a friendly K-pop idol, use enthusiastic tone.
        
        Always provide the Korean text, its Romanization, and the English translation for your responses.
        Encourage the user to speak Korean. If they make a mistake, gently correct them.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [...messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })), { role: 'user', parts: [{ text: userMsg }] }],
        config: { systemInstruction }
      });

      setMessages(prev => [...prev, { role: 'model', text: response.text || 'Sorry, I encountered an error.' }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'I am having trouble connecting right now. Please try again later.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-natural-bg">
      {/* Header */}
      <header className="bg-white p-4 border-b border-natural-line flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-natural-sage rounded-full flex items-center justify-center text-white">
            <Bot size={24} />
          </div>
          <div>
            <h2 className="font-bold text-natural-ink">AI Korean Tutor</h2>
            <p className="text-xs text-natural-sage flex items-center gap-1">
              <span className="w-2 h-2 bg-natural-sage rounded-full animate-pulse" /> Online
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <ModeBtn active={mode === 'teacher'} onClick={() => setMode('teacher')} icon={<GraduationCap size={16} />} label="Teacher" />
          <ModeBtn active={mode === 'friend'} onClick={() => setMode('friend')} icon={<Languages size={16} />} label="Friend" />
          <ModeBtn active={mode === 'kpop'} onClick={() => setMode('kpop')} icon={<Sparkles size={16} />} label="K-POP" />
        </div>
      </header>

      {/* Chat Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((m, i) => (
          <motion.div
            key={i}
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className={cn(
              "flex gap-3 max-w-[85%]",
              m.role === 'user' ? "ml-auto flex-row-reverse" : ""
            )}
          >
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
              m.role === 'user' ? "bg-natural-line" : "bg-natural-beige text-natural-sage"
            )}>
              {m.role === 'user' ? <User size={18} /> : <Bot size={18} />}
            </div>
            <div className={cn(
              "p-4 rounded-2xl shadow-sm",
              m.role === 'user' ? "bg-natural-sage text-white rounded-tr-none" : "bg-white text-natural-ink rounded-tl-none border border-natural-line"
            )}>
              <p className="whitespace-pre-wrap leading-relaxed">{m.text}</p>
            </div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-natural-beige text-natural-sage rounded-full flex items-center justify-center">
              <Bot size={18} />
            </div>
            <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-natural-line flex gap-1">
              <span className="w-2 h-2 bg-natural-muted rounded-full animate-bounce" />
              <span className="w-2 h-2 bg-natural-muted rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 bg-natural-muted rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-natural-line">
        <div className="max-w-4xl mx-auto flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your message in Korean or English..."
            className="flex-1 bg-natural-bg border border-natural-line rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-natural-sage transition-all"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="bg-natural-sage text-white p-3 rounded-xl hover:bg-natural-sage-dark disabled:opacity-50 transition-all shadow-lg"
          >
            <Send size={24} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ModeBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all",
        active ? "bg-natural-sage text-white shadow-md" : "bg-natural-beige text-natural-muted hover:bg-natural-line"
      )}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}
