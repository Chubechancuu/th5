import { motion } from 'motion/react';
import { UserProgress } from '../types';
import { Settings, Trophy, Flame, Star, BookOpen, Target, Calendar } from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  progress: UserProgress;
}

export default function ProfileScreen({ progress }: Props) {
  const stats = [
    { label: 'Streak', value: `${progress.streak} Days`, icon: <Flame className="text-natural-terracotta" />, color: 'bg-white' },
    { label: 'Total XP', value: progress.xp, icon: <Star className="text-yellow-500" />, color: 'bg-white' },
    { label: 'Lessons', value: progress.completedLessons.length, icon: <BookOpen className="text-natural-sage" />, color: 'bg-white' },
    { label: 'Level', value: Math.floor(progress.xp / 1000) + 1, icon: <Target className="text-emerald-500" />, color: 'bg-white' },
  ];

  const achievements = [
    { title: 'First Steps', desc: 'Completed your first lesson', icon: '🌱', unlocked: true },
    { title: 'Streak Master', desc: 'Reached a 7-day streak', icon: '🔥', unlocked: false },
    { title: 'AI Conversationalist', desc: 'Chatted with AI for 10 minutes', icon: '🤖', unlocked: true },
    { title: 'TOPIK Ready', desc: 'Completed Unit 5', icon: '🎓', unlocked: false },
  ];

  return (
    <div className="max-w-4xl mx-auto p-10">
      <header className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 bg-natural-sage rounded-3xl flex items-center justify-center text-white text-4xl font-bold shadow-xl">
            {progress.userId[0].toUpperCase()}
          </div>
          <div>
            <h2 className="text-3xl font-bold text-natural-ink">Guest User</h2>
            <p className="text-natural-muted flex items-center gap-2 font-medium">
              <Calendar size={16} /> Joined April 2026
            </p>
          </div>
        </div>
        <button className="p-3 bg-white text-natural-muted rounded-xl border border-natural-line hover:bg-natural-beige transition-all">
          <Settings size={24} />
        </button>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
            className={cn("p-6 rounded-3xl border border-natural-line shadow-sm", stat.color)}
          >
            <div className="mb-3">{stat.icon}</div>
            <div className="text-2xl font-bold text-natural-ink">{stat.value}</div>
            <div className="text-sm text-natural-muted font-bold uppercase tracking-wide">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <section>
          <h3 className="section-title flex items-center gap-2">
            <Trophy className="text-yellow-500" size={16} /> Achievements
          </h3>
          <div className="space-y-4">
            {achievements.map((a, i) => (
              <div
                key={i}
                className={cn(
                  "p-5 rounded-2xl border flex items-center gap-4 transition-all",
                  a.unlocked ? "bg-white border-natural-line shadow-sm" : "bg-natural-line/30 border-transparent opacity-60"
                )}
              >
                <div className="text-3xl">{a.icon}</div>
                <div>
                  <h4 className="font-bold text-natural-ink">{a.title}</h4>
                  <p className="text-sm text-natural-muted font-medium">{a.desc}</p>
                </div>
                {!a.unlocked && <div className="ml-auto text-natural-muted"><Settings size={16} /></div>}
              </div>
            ))}
          </div>
        </section>

        <section>
          <h3 className="section-title flex items-center gap-2">
            <Star className="text-natural-sage" size={16} /> Learning Goal
          </h3>
          <div className="bg-white p-8 rounded-3xl border border-natural-line shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <span className="font-bold text-natural-muted uppercase text-xs tracking-wider">Goal: {progress.currentGoal}</span>
              <span className="text-natural-sage font-black">60%</span>
            </div>
            <div className="h-4 bg-natural-beige rounded-full overflow-hidden mb-6">
              <div className="h-full bg-natural-sage w-[60%] transition-all duration-1000" />
            </div>
            <p className="text-natural-ink text-sm leading-relaxed font-medium">
              You are doing great! Complete 3 more lessons this week to stay on track for your goal.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
