import { motion } from 'motion/react';
import { UserProgress } from '../types';
import { MOCK_LESSONS } from '../data/lessons';
import { CheckCircle2, Lock, Star, Play } from 'lucide-react';
import { cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

interface Props {
  progress: UserProgress;
}

export default function HomeScreen({ progress }: Props) {
  const navigate = useNavigate();

  const units = [
    { id: 'u1', title: 'Unit 1: Hangul', desc: 'The Korean Alphabet', color: 'bg-natural-terracotta' },
    { id: 'u2', title: 'Unit 2: Basic Greetings', desc: 'Saying Hello and Goodbye', color: 'bg-natural-terracotta' },
    { id: 'u3', title: 'Unit 3: Daily Life', desc: 'Common objects and actions', color: 'bg-natural-terracotta' },
  ];

  return (
    <div className="max-w-3xl mx-auto py-12 px-8">
      <div className="space-y-20">
        {units.map((unit, unitIdx) => (
          <div key={unit.id} className="relative">
            <div className={cn("p-8 rounded-[20px] text-white mb-12 flex justify-between items-center shadow-lg", unit.color)}>
              <div className="unit-info">
                <h2 className="text-2xl font-bold">{unit.title}</h2>
                <p className="opacity-90 text-sm mt-1">{unit.desc}</p>
              </div>
              <button className="bg-white text-natural-terracotta px-6 py-3 rounded-xl font-extrabold text-sm uppercase tracking-wider shadow-sm hover:scale-105 transition-transform">
                Học tiếp ngay
              </button>
            </div>

            <div className="flex flex-col items-center gap-10 relative">
              {MOCK_LESSONS.filter(l => l.unitId === unit.id).map((lesson, idx) => {
                const isCompleted = progress.completedLessons.includes(lesson.id);
                const isLocked = unitIdx > 0 && !isCompleted; 

                return (
                  <div key={lesson.id} className="flex flex-col items-center">
                    {idx > 0 && (
                      <div 
                        className={cn(
                          "w-0.5 h-10 mb-10",
                          isCompleted ? "bg-natural-sage" : "bg-natural-line"
                        )} 
                      />
                    )}
                    <motion.div
                      whileHover={!isLocked ? { scale: 1.05 } : {}}
                      whileTap={!isLocked ? { scale: 0.95 } : {}}
                      className="relative"
                    >
                      <button
                        onClick={() => !isLocked && navigate(`/lesson/${lesson.id}`)}
                        className={cn(
                          "w-[90px] h-[85px] rounded-full flex items-center justify-center transition-all relative border-[5px]",
                          isCompleted ? "bg-natural-sage border-natural-sage text-white shadow-[0_4px_0_#6B7A46]" : 
                          isLocked ? "bg-white border-natural-line text-natural-muted shadow-[0_4px_0_#E5E0D8] cursor-not-allowed" : 
                          "bg-[#F1F4E8] border-natural-sage text-natural-sage shadow-[0_4px_0_#6B7A46]"
                        )}
                      >
                        {isCompleted ? <CheckCircle2 size={32} /> : 
                         isLocked ? <Lock size={24} /> : 
                         <span className="text-3xl">📖</span>}
                        
                        <div className="absolute top-full mt-3 font-bold text-sm whitespace-nowrap text-natural-ink">
                          {lesson.title}
                        </div>
                      </button>
                    </motion.div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
