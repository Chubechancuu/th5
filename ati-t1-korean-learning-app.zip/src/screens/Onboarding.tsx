import { useState } from 'react';
import { motion } from 'motion/react';
import { Level } from '../types';
import { ChevronRight, GraduationCap, Plane, Music, MessageCircle, Target } from 'lucide-react';

interface Props {
  onComplete: (level: Level, goal: string) => void;
}

export default function OnboardingScreen({ onComplete }: Props) {
  const [step, setStep] = useState(1);
  const [level, setLevel] = useState<Level>('Beginner');
  const [goal, setGoal] = useState('');

  const levels: { id: Level; label: string; desc: string }[] = [
    { id: 'Beginner', label: 'Beginner', desc: 'Starting from scratch (Hangul)' },
    { id: 'Intermediate', label: 'Intermediate', desc: 'Can hold basic conversations' },
    { id: 'Advanced', label: 'Advanced', desc: 'Fluent or preparing for TOPIK 5/6' },
  ];

  const goals = [
    { id: 'travel', label: 'Travel', icon: <Plane className="text-blue-500" /> },
    { id: 'kpop', label: 'K-POP / Drama', icon: <Music className="text-pink-500" /> },
    { id: 'topik', label: 'TOPIK Exam', icon: <GraduationCap className="text-indigo-500" /> },
    { id: 'conversation', label: 'Conversation', icon: <MessageCircle className="text-green-500" /> },
  ];

  return (
    <div className="min-h-screen bg-natural-bg flex flex-col items-center justify-center p-6">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="inline-block p-4 bg-white rounded-3xl mb-6 shadow-xl border border-natural-line"
          >
            <Target className="text-natural-sage w-10 h-10" />
          </motion.div>
          <h2 className="text-4xl font-black text-natural-ink tracking-tight">Chào mừng đến với ATI T1</h2>
          <p className="text-natural-muted mt-3 font-bold">Hãy cá nhân hóa hành trình học tập của bạn</p>
        </div>

        {step === 1 ? (
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="space-y-4"
          >
            <h3 className="text-xl font-black mb-6 text-natural-ink uppercase tracking-wider text-center">Trình độ của bạn là gì?</h3>
            {levels.map((l) => (
              <button
                key={l.id}
                onClick={() => setLevel(l.id)}
                className={`w-full p-5 rounded-2xl border-2 text-left transition-all shadow-sm ${
                  level === l.id ? 'border-natural-sage bg-natural-beige text-natural-sage' : 'border-natural-line bg-white hover:border-natural-muted'
                }`}
              >
                <div className="font-black text-xl">{l.label}</div>
                <div className="text-natural-muted text-sm font-bold mt-1">{l.desc}</div>
              </button>
            ))}
            <button
              onClick={() => setStep(2)}
              className="w-full bg-natural-sage text-white p-5 rounded-2xl font-black text-lg flex items-center justify-center gap-2 mt-10 shadow-lg hover:bg-natural-sage-dark transition-all"
            >
              Tiếp theo <ChevronRight size={24} />
            </button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="space-y-4"
          >
            <h3 className="text-xl font-black mb-6 text-natural-ink uppercase tracking-wider text-center">Mục tiêu của bạn là gì?</h3>
            <div className="grid grid-cols-2 gap-5">
              {goals.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setGoal(g.id)}
                  className={`p-8 rounded-3xl border-2 flex flex-col items-center gap-4 transition-all shadow-sm ${
                    goal === g.id ? 'border-natural-sage bg-natural-beige text-natural-sage' : 'border-natural-line bg-white hover:border-natural-muted'
                  }`}
                >
                  <div className="p-4 bg-white rounded-2xl shadow-md border border-natural-line">{g.icon}</div>
                  <div className="font-black text-sm uppercase tracking-wide">{g.label}</div>
                </button>
              ))}
            </div>
            <div className="flex gap-4 mt-10">
              <button
                onClick={() => setStep(1)}
                className="flex-1 border-2 border-natural-line bg-white p-5 rounded-2xl font-black text-natural-muted hover:bg-natural-beige transition-all"
              >
                Quay lại
              </button>
              <button
                disabled={!goal}
                onClick={() => onComplete(level, goal)}
                className="flex-[2] bg-natural-sage text-white p-5 rounded-2xl font-black text-lg disabled:opacity-50 shadow-lg hover:bg-natural-sage-dark transition-all"
              >
                Bắt đầu học ngay
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
