import { Lesson } from "../types";

export const MOCK_LESSONS: Lesson[] = [
  {
    id: "h1",
    unitId: "u1",
    title: "Hangul Basics 1",
    description: "Learn the basic vowels and consonants.",
    type: "vocabulary",
    vocabulary: [
      { word: "ㅏ", meaning: "a", example: "가 (ga)" },
      { word: "ㅣ", meaning: "i", example: "기 (gi)" },
      { word: "ㅜ", meaning: "u", example: "구 (gu)" },
    ],
    quiz: [
      {
        id: "q1",
        question: "Which one is 'a'?",
        options: ["ㅏ", "ㅣ", "ㅜ"],
        correctAnswer: "ㅏ",
        type: "multiple-choice"
      }
    ]
  },
  {
    id: "b1",
    unitId: "u2",
    title: "Greetings",
    description: "Basic greetings in Korean.",
    type: "conversation",
    vocabulary: [
      { word: "안녕하세요", meaning: "Hello", example: "안녕하세요, 반갑습니다." },
      { word: "감사합니다", meaning: "Thank you", example: "정말 감사합니다." },
    ],
    quiz: [
      {
        id: "q2",
        question: "How do you say 'Hello'?",
        options: ["안녕하세요", "감사합니다", "미안합니다"],
        correctAnswer: "안녕하세요",
        type: "multiple-choice"
      }
    ]
  }
];
