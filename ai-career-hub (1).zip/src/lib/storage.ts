import { UserProfile, Task, ChatMessage } from '../types';

const STORAGE_KEYS = {
  USER_PROFILE: 'career_hub_user_profile',
  TASKS: 'career_hub_tasks',
  CHAT_HISTORY: 'career_hub_chat_history',
  STREAK_LAST_DATE: 'career_hub_streak_last_date',
  THEME: 'career_hub_theme'
};

export const storage = {
  getUserProfile: (): UserProfile => {
    const data = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!data) return {
      name: '',
      goal: '',
      year: '',
      gpa: '',
      xp: 0,
      level: 1,
      streak: 0,
      focusTime: 0,
      completedTasks: 0,
      badges: [],
      onboarded: false
    };
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error('Failed to parse user profile', e);
      return storage.getUserProfile(); // Return default
    }
  },

  setUserProfile: (profile: UserProfile) => {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  },

  getTasks: (): Task[] => {
    const data = localStorage.getItem(STORAGE_KEYS.TASKS);
    if (!data) return [];
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error('Failed to parse tasks', e);
      return [];
    }
  },

  setTasks: (tasks: Task[]) => {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  },

  getChatHistory: (): ChatMessage[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHAT_HISTORY);
    if (!data) return [];
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error('Failed to parse chat history', e);
      return [];
    }
  },

  setChatHistory: (history: ChatMessage[]) => {
    localStorage.setItem(STORAGE_KEYS.CHAT_HISTORY, JSON.stringify(history));
  },

  updateStreak: () => {
    const profile = storage.getUserProfile();
    const lastDate = localStorage.getItem(STORAGE_KEYS.STREAK_LAST_DATE);
    const today = new Date().toDateString();

    if (lastDate === today) return;

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (lastDate === yesterday.toDateString()) {
      profile.streak += 1;
    } else {
      profile.streak = 1;
    }

    localStorage.setItem(STORAGE_KEYS.STREAK_LAST_DATE, today);
    storage.setUserProfile(profile);
  },

  getTheme: () => localStorage.getItem(STORAGE_KEYS.THEME) || 'light',
  setTheme: (theme: string) => localStorage.setItem(STORAGE_KEYS.THEME, theme)
};
