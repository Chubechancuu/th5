import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Calendar, 
  AlertCircle, 
  Filter, 
  Sparkles,
  Loader2,
  ChevronDown,
  GripVertical
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Task, UserProfile } from '../types';
import { cn } from '../lib/utils';
import { generateTasksFromChat } from '../lib/gemini';

interface TaskManagerProps {
  tasks: Task[];
  setTasks: (tasks: Task[]) => void;
  user: UserProfile;
  addXP: (amount: number) => void;
}

export default function TaskManager({ tasks, setTasks, user, addXP }: TaskManagerProps) {
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [filter, setFilter] = useState<'all' | 'pending' | 'done'>('all');
  const [isGenerating, setIsGenerating] = useState(false);

  const addTask = (title: string, priority: 'low' | 'medium' | 'high' = 'medium', days = 1) => {
    if (!title.trim()) return;
    const newTask: Task = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      priority,
      status: 'pending',
      deadline: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      createdAt: Date.now()
    };
    setTasks([newTask, ...tasks]);
    setNewTaskTitle('');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => {
      if (t.id === id) {
        const newStatus = t.status === 'pending' ? 'done' : 'pending';
        if (newStatus === 'done') addXP(50);
        return { ...t, status: newStatus };
      }
      return t;
    }));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const handleAiSuggest = async () => {
    setIsGenerating(true);
    try {
      // In a real app, we'd pass actual chat history. For now, we use a placeholder or the user's goal.
      const result = await generateTasksFromChat("Sinh viên muốn tìm hiểu về phân tích dữ liệu và thực tập tại Big4.", user.goal);
      result.tasks.forEach((t: any) => addTask(t.title, t.priority, t.daysToDeadline));
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const filteredTasks = tasks.filter(t => {
    if (filter === 'pending') return t.status === 'pending';
    if (filter === 'done') return t.status === 'done';
    return true;
  });

  return (
    <div className="card h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-bold text-text-main">Smart Task Manager</h3>
          <p className="text-[11px] text-text-sub uppercase font-bold tracking-wider">AI-Powered Productivity</p>
        </div>
        <button 
          onClick={handleAiSuggest}
          disabled={isGenerating}
          className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-[12px] font-bold hover:bg-primary/20 transition-all disabled:opacity-50"
        >
          {isGenerating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
          AI Suggest
        </button>
      </div>

      <div className="flex gap-2 mb-6">
        <input 
          type="text" 
          value={newTaskTitle}
          onChange={(e) => setNewTaskTitle(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addTask(newTaskTitle)}
          placeholder="Add a new task..."
          className="flex-1 bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary transition-colors"
        />
        <button 
          onClick={() => addTask(newTaskTitle)}
          className="p-2 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors"
        >
          <Plus size={20} />
        </button>
      </div>

      <div className="flex items-center gap-4 mb-4 border-b border-border pb-2">
        {(['all', 'pending', 'done'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "text-[12px] font-bold uppercase tracking-wider pb-2 transition-all relative",
              filter === f ? "text-primary" : "text-text-sub hover:text-text-main"
            )}
          >
            {f}
            {filter === f && <motion.div layoutId="filter-active" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
        <AnimatePresence mode="popLayout">
          {filteredTasks.map((task) => (
            <motion.div
              key={task.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={cn(
                "group p-4 rounded-xl border transition-all flex items-center gap-4",
                task.status === 'done' ? "bg-bg border-transparent opacity-60" : "bg-surface border-border hover:border-primary/30"
              )}
            >
              <button 
                onClick={() => toggleTask(task.id)}
                className={cn(
                  "shrink-0 transition-colors",
                  task.status === 'done' ? "text-secondary" : "text-text-sub hover:text-primary"
                )}
              >
                {task.status === 'done' ? <CheckCircle2 size={22} /> : <Circle size={22} />}
              </button>

              <div className="flex-1 min-w-0">
                <h4 className={cn(
                  "text-[14px] font-bold truncate",
                  task.status === 'done' ? "line-through text-text-sub" : "text-text-main"
                )}>
                  {task.title}
                </h4>
                <div className="flex items-center gap-3 mt-1">
                  <span className="flex items-center gap-1 text-[11px] text-text-sub">
                    <Calendar size={12} /> {task.deadline}
                  </span>
                  <span className={cn(
                    "text-[10px] font-black uppercase px-1.5 py-0.5 rounded",
                    task.priority === 'high' ? "bg-red-100 text-red-600" :
                    task.priority === 'medium' ? "bg-orange-100 text-orange-600" :
                    "bg-blue-100 text-blue-600"
                  )}>
                    {task.priority}
                  </span>
                </div>
              </div>

              <button 
                onClick={() => deleteTask(task.id)}
                className="opacity-0 group-hover:opacity-100 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
              >
                <Trash2 size={16} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {filteredTasks.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-bg rounded-full flex items-center justify-center mx-auto mb-4 text-text-sub">
              <Filter size={24} />
            </div>
            <p className="text-text-sub text-[13px] font-medium">No tasks found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
