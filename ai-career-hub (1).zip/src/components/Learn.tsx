import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  Circle, 
  Sparkles, 
  Loader2, 
  ChevronRight,
  Target,
  Award,
  Zap,
  Star,
  Trophy,
  Edit3,
  Plus,
  Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, RoadmapItem } from '../types';
import { generateRoadmap } from '../lib/gemini';
import { cn } from '../lib/utils';

interface LearnProps {
  user: UserProfile;
}

export default function Learn({ user }: LearnProps) {
  const [roadmap, setRoadmap] = useState<RoadmapItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeYear, setActiveYear] = useState('Năm 1');
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    const fetchRoadmap = async () => {
      setIsLoading(true);
      try {
        const result = await generateRoadmap(user.year, user.gpa, user.goal);
        const roadmapWithIds = result.roadmap.map((item: any) => ({
          ...item,
          id: item.id || Math.random().toString(36).substr(2, 9)
        }));
        setRoadmap(roadmapWithIds);
        setActiveYear(user.year || 'Năm 1');
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchRoadmap();
  }, [user.goal, user.year]);

  const activeData = roadmap.find(r => r.year === activeYear) || roadmap[0];

  const updateRoadmapItem = (id: string, updates: Partial<RoadmapItem>) => {
    setRoadmap(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const handleAddTask = (id: string) => {
    const item = roadmap.find(r => r.id === id);
    if (item) {
      updateRoadmapItem(id, { tasks: [...item.tasks, 'Nhiệm vụ mới'] });
    }
  };

  const handleRemoveTask = (id: string, index: number) => {
    const item = roadmap.find(r => r.id === id);
    if (item) {
      updateRoadmapItem(id, { tasks: item.tasks.filter((_, i) => i !== index) });
    }
  };

  const handleAddSkill = (id: string) => {
    const item = roadmap.find(r => r.id === id);
    if (item) {
      updateRoadmapItem(id, { skills: [...(item.skills || []), 'Kỹ năng mới'] });
    }
  };

  const handleRemoveSkill = (id: string, index: number) => {
    const item = roadmap.find(r => r.id === id);
    if (item && item.skills) {
      updateRoadmapItem(id, { skills: item.skills.filter((_, i) => i !== index) });
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-text-main tracking-tight">Lộ trình phát triển 4 năm</h1>
          <p className="text-text-sub font-medium mt-1">Lộ trình cá nhân hóa dựa trên mục tiêu {user.goal}.</p>
        </div>
        <button 
          onClick={() => window.location.reload()}
          className="flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-xl text-[14px] font-bold hover:bg-primary/20 transition-all"
        >
          <Zap size={18} /> Cập nhật lộ trình
        </button>
      </div>

      {isLoading ? (
        <div className="card py-20 text-center space-y-6">
          <Loader2 className="animate-spin mx-auto text-primary" size={48} />
          <div>
            <h3 className="text-xl font-black text-text-main">AI đang phân tích thị trường...</h3>
            <p className="text-text-sub font-medium mt-2">Đang thiết kế lộ trình tối ưu cho mục tiêu {user.goal}.</p>
          </div>
        </div>
      ) : roadmap.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Year Selection */}
          <div className="space-y-3">
            {roadmap.map((item) => (
              <button
                key={item.year}
                onClick={() => setActiveYear(item.year)}
                className={cn(
                  "w-full p-5 rounded-[20px] border text-left transition-all group relative overflow-hidden",
                  activeYear === item.year 
                    ? "bg-primary text-white border-primary shadow-lg shadow-primary/20" 
                    : "bg-surface border-border text-text-sub hover:border-primary/30 hover:bg-bg"
                )}
              >
                <div className="flex items-center justify-between relative z-10">
                  <span className="font-black text-lg tracking-tight">{item.year}</span>
                  <ChevronRight size={18} className={cn("transition-transform", activeYear === item.year ? "translate-x-1" : "group-hover:translate-x-1")} />
                </div>
                <div className={cn(
                  "text-[11px] font-bold uppercase tracking-widest mt-1 relative z-10",
                  activeYear === item.year ? "text-white/70" : "text-text-sub"
                )}>
                  {item.year === user.year ? 'Năm hiện tại' : 'Kế hoạch'}
                </div>
                {activeYear === item.year && (
                  <motion.div layoutId="year-bg" className="absolute inset-0 bg-primary" />
                )}
              </button>
            ))}
          </div>

          {/* Year Content */}
          <div className="lg:col-span-3 space-y-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeYear}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {/* Advice Card */}
                <div className="card bg-primary/5 border-primary/10 p-8 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-40 h-40 bg-primary/5 -mr-20 -mt-20 rounded-full" />
                  <div className="flex items-start gap-4 relative">
                    <div className="w-12 h-12 bg-primary text-white rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-primary/20">
                      <Sparkles size={24} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-[14px] font-black text-primary uppercase tracking-wider">Lời khuyên chiến lược</h3>
                        <button 
                          onClick={() => setEditingId(editingId === activeData.id ? null : activeData.id)}
                          className="p-1.5 hover:bg-primary/10 rounded-lg text-primary transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Edit3 size={16} />
                        </button>
                      </div>
                      {editingId === activeData.id ? (
                        <textarea 
                          value={activeData.advice}
                          onChange={(e) => updateRoadmapItem(activeData.id, { advice: e.target.value })}
                          className="w-full bg-surface border border-primary/20 rounded-xl p-4 text-lg font-bold leading-relaxed italic focus:outline-none focus:border-primary h-32 resize-none"
                        />
                      ) : (
                        <p className="text-text-main text-lg font-bold leading-relaxed italic">
                          "{activeData.advice}"
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Tasks */}
                  <div className="card space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                        <Target size={20} className="text-primary" /> Nhiệm vụ trọng tâm
                      </h3>
                      <button 
                        onClick={() => handleAddTask(activeData.id)}
                        className="p-1.5 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-all"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    <div className="space-y-3">
                      {activeData.tasks.map((task, i) => (
                        <div key={i} className="flex items-start gap-4 p-4 bg-bg rounded-[18px] border border-border group hover:border-primary/30 transition-all">
                          <div className="mt-1 text-text-sub group-hover:text-primary transition-colors">
                            <Circle size={18} />
                          </div>
                          <div className="flex-1">
                            {editingId === activeData.id ? (
                              <div className="flex items-center gap-2">
                                <input 
                                  type="text"
                                  value={task}
                                  onChange={(e) => {
                                    const newTasks = [...activeData.tasks];
                                    newTasks[i] = e.target.value;
                                    updateRoadmapItem(activeData.id, { tasks: newTasks });
                                  }}
                                  className="flex-1 bg-surface border border-border rounded-lg px-3 py-1 text-[14px] font-bold text-text-main focus:outline-none focus:border-primary"
                                />
                                <button 
                                  onClick={() => handleRemoveTask(activeData.id, i)}
                                  className="p-1 text-text-sub hover:text-red-500"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            ) : (
                              <span className="text-[14px] font-bold text-text-main leading-tight">{task}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="card space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                        <Award size={20} className="text-secondary" /> Kỹ năng cần đạt
                      </h3>
                      <button 
                        onClick={() => handleAddSkill(activeData.id)}
                        className="p-1.5 bg-secondary/10 text-secondary rounded-lg hover:bg-secondary/20 transition-all"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    <div className="space-y-4">
                      {activeData.skills?.map((skill, i) => (
                        <div key={i} className="space-y-2 group">
                          <div className="flex justify-between items-center">
                            {editingId === activeData.id ? (
                              <div className="flex items-center gap-2 flex-1">
                                <input 
                                  type="text"
                                  value={skill}
                                  onChange={(e) => {
                                    const newSkills = [...(activeData.skills || [])];
                                    newSkills[i] = e.target.value;
                                    updateRoadmapItem(activeData.id, { skills: newSkills });
                                  }}
                                  className="flex-1 bg-surface border border-border rounded-lg px-3 py-1 text-[14px] font-bold text-text-main focus:outline-none focus:border-primary"
                                />
                                <button 
                                  onClick={() => handleRemoveSkill(activeData.id, i)}
                                  className="p-1 text-text-sub hover:text-red-500"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            ) : (
                              <>
                                <span className="text-[14px] font-bold text-text-main">{skill}</span>
                                <Star size={14} className="text-accent fill-accent" />
                              </>
                            )}
                          </div>
                          <div className="h-2 bg-bg rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: '100%' }}
                              transition={{ delay: i * 0.2, duration: 1 }}
                              className="h-full bg-secondary"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-8 p-6 bg-secondary/5 rounded-[24px] border border-secondary/10 text-center">
                      <div className="w-12 h-12 bg-secondary/10 text-secondary rounded-full flex items-center justify-center mx-auto mb-3">
                        <Trophy size={24} />
                      </div>
                      <h4 className="font-black text-secondary text-[14px] uppercase tracking-wider">Phần thưởng hoàn thành</h4>
                      <p className="text-[12px] text-text-sub font-medium mt-1">Hoàn thành tất cả nhiệm vụ để nhận 500 XP và Huy hiệu {activeYear}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      ) : (
        <div className="card py-20 text-center">
          <p className="text-text-sub font-medium">Không thể tải lộ trình. Vui lòng thử lại sau.</p>
        </div>
      )}
    </div>
  );
}
